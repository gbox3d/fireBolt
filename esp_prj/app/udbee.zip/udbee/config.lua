app_config={
    station_cfg = nil,--{"","",9,2},
    ap_cfg={4},
    remote={ip ="192.168.9.2",port=5683},
    local_info={port=1471},
    baud=115200,autostart=false,safedelay=25,
    --parser=string.char(0x81)
    parser=0
    }

